import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import './components/Sidebar.css'; // Global CSS dosyasını içe aktarıyoruz

ReactDOM.render(<App />, document.getElementById('root'));